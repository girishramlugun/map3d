export MAP3D_WORK=${HOME}/gl/map3d
export LD_LIBRARY_PATH=/usr/local/lib:$MAP3D_WORK/cutil:$MAP3D_WORK/fi:$MAP3D_WORK/fids:$MAP3D_WORK/gfile:$MAP3D_WORK/graphicsio:$MAP3D_WORK/numseq
export LD_LIBRARYN32_PATH=/usr/local/lib:$MAP3D_WORK/cutil:$MAP3D_WORK/fi:$MAP3D_WORK/fids:$MAP3D_WORK/gfile:$MAP3D_WORK/graphicsio:$MAP3D_WORK/numseq
