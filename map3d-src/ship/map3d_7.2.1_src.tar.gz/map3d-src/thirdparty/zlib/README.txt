This needed to be included because Qt 5 stopped allowing public access to zlib
