 /*** 
   Filename: splitline.c
   Author: Rob MacLeod
 ***/
char *SplitLine (const char *sep, 
