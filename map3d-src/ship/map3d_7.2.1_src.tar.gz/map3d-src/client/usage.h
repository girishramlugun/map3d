/* usage.h */

#ifndef USAGE_H
#define USAGE_H

#ifdef __cplusplus
extern "C"
{
#endif

#define VERSION "7.2"

  void PrintUsageStatement(bool versiononly);

#ifdef __cplusplus
}
#endif

#endif
