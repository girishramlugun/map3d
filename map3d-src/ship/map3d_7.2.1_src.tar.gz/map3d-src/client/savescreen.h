/* savescreen.h */

#ifndef _SAVESCREEN_H
#define _SAVESCREEN_H

class Texture;

void SaveScreen();
Texture* readImage(const char* filename);

#endif
