/* reportstate.h */
#ifndef REPORTSTATE_H
#define REPORTSTATE_H

#ifdef __cplusplus
extern "C"
{
#endif


  void ReportMeshRender(int drawmesh);
  void ReportShading(int shadingmodel);

#ifdef __cplusplus
}
#endif

#endif
