/* lock.h */

#ifndef LOCK_H
#define LOCK_H

#ifdef __cplusplus
#define EXTERN extern "C"
#else
#define EXTERN extern
#endif

EXTERN unsigned char padlock[];

#endif
