/* dot.h */

#ifndef DOT_H
#define DOT_H

#ifdef __cplusplus
#define EXTERN extern "C"
#else
#define EXTERN extern
#endif

EXTERN unsigned char dot[];

#endif
